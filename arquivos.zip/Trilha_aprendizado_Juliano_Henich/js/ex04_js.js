var n1, n2, result
n1=8;
n2=20;
result=n1+n2;
alert(n1);
alert(n2);
frase = "O resultado da soma"
alert(frase + " " + n1 + "+" + n2 + "=" + result);