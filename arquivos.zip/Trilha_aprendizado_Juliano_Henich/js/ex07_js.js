var n1, n2
n1 = prompt("Digite o primeiro valor")
n2 = prompt("Digite o segundo valor")
if(n1>n2){
    alert("O primeiro número é maior " + n1 + " maior que " + n2)
}
else if(n2>n1){
    alert("O segundo número é maior " + n2 + " maior que " + n1)
}
else{
    alert("Os números são iguais " + n1 + " igual a " + n2)
}