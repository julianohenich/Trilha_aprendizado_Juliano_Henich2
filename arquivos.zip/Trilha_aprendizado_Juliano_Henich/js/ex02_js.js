alert("Inserção de javascript externo");

prompt("Digite seu nome:");

confirm("Voce tem mais de 18 anos?");