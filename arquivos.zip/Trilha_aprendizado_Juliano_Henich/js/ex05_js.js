var n1, n2, resultado
n1 = prompt("Digite o primeiro valor")
n2 = prompt("Digite o segundo valor")
resultado = parseInt(n1) + parseInt(n2)
alert("A soma é " + resultado)
