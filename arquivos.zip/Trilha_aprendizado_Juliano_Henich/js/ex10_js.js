var cont

/*while (cont<10) {
    alert("Enlouqueçendo o usuario com while" +cont)
    cont++
}*/

for (cont = 0; cont < 10; cont++) {
    
    alert("Enlouqueçendo o usuario com for " +cont)
}