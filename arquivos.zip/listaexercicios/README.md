# listaexercicios
 
